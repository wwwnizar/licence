#!/bin/bash
sbt runtime/publishSigned codegen/publishSigned sonatypeRelease
